<?php
// $name='mutahar';
// $id='ukhano';
// $channel_id=$id;
// $views=3;
// $comments=3;
// $subscribers=2;
// $hiddenSubscriber=1;
// $videos=4;
// $time=5;
// $url='images\m.jpg';
include 'insertData.php';
// require_once 'config.php';
// include 'chart_data.php';
// include 'graph_data.php';


// include 'insertData.php';
$id = $_GET['id'];
$name = $_GET['name'];
// echo($channel_code."<br>");
$id = stristr($id, "channel/");
// echo($channel_code."<br>");
$id = str_replace("channel/", "", $id);
// echo $id;
// $id = $_GET['id'];
// $name = $_GET['name'];
$time = date("d/m/y");
$api_key = 'AIzaSyA1V1Ws5sqqCMGWT5OsrJdrAzRYAc_Rnv4';
// https://www.youtube.com/channel/UCG8rbF3g2AMX70yOd8vqIZg
$json  =file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id='.$id.'&key='.$api_key) ;
$image_url=file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=snippet&fields=items%2Fsnippet%2Fthumbnails%2Fdefault&id='.$id.'&key='.$api_key);
// echo $image;
// echo($json);

// Define recursive function to extract nested values
function printValues($arr) {
    global $count;
    global $values;
    // Check input is an array
    if(!is_array($arr)){
        die("<br>"."Sorry: Somethhing Went Wrong");
    }
    foreach($arr as $key=>$value){
        if(is_array($value)){
            printValues($value);
        } else{
            $values[] = $value;
            $count++;
        }
    }
    
    return array($values);
}

$arr = json_decode($json, true);
$result = printValues($arr);
echo "<br>";
// print_r($result);
$image=json_decode($image_url,true);
$result2 = printValues($image);
$url=$result2[0][11];
// echo "<img src='$url'>";

$channelid = $result[0][6];
$views = $result[0][7];
$comments = $result[0][8];
$subscribers = $result[0][8];
$hiddenSubscriber = $result[0][9];
$videos = $result[0][10];
$image=$url;

if (empty($hiddenSubscriber)) {
  $hiddenSubscriber='No';
}
else{
  $hiddenSubscriber='Yess';
}

dataBase($channelid,$views,$comments,$subscribers,$hiddenSubscriber,$videos);


// echo $name;
// echo "<br>";
// echo($id);
// echo "<br>";
// $api_key = 'AIzaSyBAedC5mGYO0m8vc0sROju1Q572ApnXJ9c';
// $api_key = 'AIzaSyAItyv4Ku7ggkJQhEYutrbgOueEzmq3ZxQ';
// $api_key = 'AIzaSyCgLTLapxsIE3iKUQQ3K2tWL054oq7nOCM';
// $api_key = 'AIzaSyAJ0pVwKYt39ruExiQRfU4El841RPaf_TY';
// $api_key = 'AIzaSyBOv1EZq-j6SGobJdBqyZ4B5nnQKU49kQo';
// $api_key = 'AIzaSyBAedC5mGYO0m8vc0sROju1Q572ApnXJ9c';
// // https://www.youtube.com/channel/UCG8rbF3g2AMX70yOd8vqIZg
// $json  =file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id='.$id.'&key='.$api_key) ;

// echo($json);

// // Define recursive function to extract nested values
// function printValues($arr) {
//     global $count;
//     global $values;
    
//     // Check input is an array
//     if(!is_array($arr)){
//         die("<br>"."Sorry: Somethhing Went Wrong");
//     }
//     foreach($arr as $key=>$value){
//         if(is_array($value)){
//             printValues($value);
//         } else{
//             $values[] = $value;
//             $count++;
//         }
//     }
    
//     return array($values);
// }
 
// $arr = json_decode($json, true);
// $result = printValues($arr);
// // echo "<br>";
// // print_r($result);

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Social-Blade | Statistics</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Barlow+Condensed:500,600,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="table.css">

  </head>
  <body>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
                <a class="navbar-brand" href="index.php"><img src="images/4.gif" height="55"></span>Socialblade</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="search.php" class="nav-link">Search</a></li>
            <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
            <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
            <li class="nav-item"><a href="login.php" class="nav-link">Login</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->



    <section class="hero-wrap hero-wrap-2" style="background-image: url();" data-stellar-background-ratio="0.5">

      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h2 class="mb-0 bread">Statistics</h2>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-round-forward"></i></a></span> <span>Statistics <i class="ion-ios-arrow-round-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-degree-bg">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 sidebar ftco-animate">
            <!-- <br><br> -->
            <div class="sidebar-box bg-light" style="width: 800px; position: center; text-align: center;margin-left: 120px;">
              <img src="<?php echo $image; ?>" style="width: 100px;height: 100px; border-radius: 50%">
              <h2><?php echo $name;  ?></h2>
              <p class="button text-center"><a href="detail.php?name=<?php echo $name;?>&id=<?php echo $id; ?>" class="btn btn-primary px-4 py-3">Contact <?php echo $name; ?></p></a></p>
            </div>

            <div class="sidebar-box bg-light ftco-animate" style="width: 800px; position: center; margin-left: 120px">
              <h3 class="heading-2" style="text-align: center">Channel Overview</h3>

              <ul class="categories">
                <li><a href="#">Subscribers Hidden <span>(<?php echo($hiddenSubscriber)  ?>)</span></a></li>
                <li><a href="#">Subscribers <span>(<?php echo($subscribers)  ?>)</span></a></li>
                <li><a href="#">Views <span>(<?php echo($views) ?>)</span></a></li>
                <li><a href="#">Videos <span>(<?php echo($videos) ?>)</span></a></li>
                <li><a href="#">Time <span>(<?php echo($time) ?>)</span></a></li>
                <li><a href="#">Channel Id <span>(<?php echo($id)  ?>)</span></a></li>
              </ul>
              <br>
                <p class="button text-center"><a href="detail.php?name=<?php echo $name;?>&id=<?php echo $id; ?>" class="btn btn-primary px-4 py-3">Show Detail Stats</p></a></p>
            </div>

          </div>
        </div>
      </div>
    </section> 

    <!-- .section -->


<footer class="ftco-footer ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2 logo">Socialblade</h2>
              <p>Get a deeper understanding of user growth and trends by utilizing Social Blade</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Information</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">FAQs</a></li>
                <li><a href="#" class="py-2 d-block">Privacy</a></li>
                <li><a href="#" class="py-2 d-block">Terms Condition</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Links</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Home</a></li>
                <li><a href="#" class="py-2 d-block">Search</a></li>
                <li><a href="#" class="py-2 d-block">Gallery</a></li>
                <li><a href="#" class="py-2 d-block">About</a></li>
                <li><a href="#" class="py-2 d-block">Contact</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Have a Questions?</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text">Muhammad Ali Jinnah University, Karachi, Pakistan</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text">+92 3493885710</span></a></li>
                  <li><a href="#"><span class="icon icon-envelope"></span><span class="text">mutaharrizwan03@gmail.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>