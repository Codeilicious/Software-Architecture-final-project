<?php
// require_once 'config.php';
function dataBase( $channelid,$views,$comments,$subscribers,$hiddenSubscriber,$videos)
{
    require_once "config.php";

    // $channelid = $views = $comments = $subscribers = $hiddenSubscriber = $videos = "";
    $sql = "INSERT INTO users (channelid,views,comments,subscribers,hiddenSubscriber,videos) VALUES (?,?,?,?,?,?)";
     
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "ssssss",$param_channelid,$param_views,$param_comments,$param_subscribers,$param_hiddenSubscriber,$param_videos);
        
        // Set parameters
        $param_channelid = $channelid;
        $param_views =  $views;
        $param_comments = $comments;
        $param_subscribers = $subscribers;
        $param_hiddenSubscriber = $hiddenSubscriber;
        $param_videos = $videos;

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // Redirect to login page
            // echo("inserted");
            // header("location: index.php");
        } else{
            // echo "Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);

    mysqli_close($link);
    // echo "inserted";
}
// dataBase('logan bhayya',5,6,7,'true',8);
// $views=array();
// $times=array();
// $sql = "SELECT distinct views,time FROM users";
// $result = mysqli_query($link,$sql);
// if (mysqli_num_rows($result)>0) {
//     while ($row = mysqli_fetch_assoc($result)) {
//         $view =  $row['views'];
//         $time = $row['time'];
//         array_push($views, $view);
//         array_push($times, $time);

//         // echo $sub_jan;
//         // echo "<br>";
//     }
// }
// print_r($views);
// echo $views[0];
?>
