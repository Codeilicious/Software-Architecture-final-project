<?php
$name='mutahar';
$id='ukhano';
$channel_id=$id;
$views=3;
$comments=3;
$subscribers=2;
$hiddenSubscriber=1;
$videos=4;
$time=5;
$url='images\m.jpg';

require_once 'config.php';
include 'chart_data.php';
include 'graph_data.php';
// $id = $_GET['id'];
// $name = $_GET['name'];
// $time = date("d/m/y");
// $api_key = 'AIzaSyBAedC5mGYO0m8vc0sROju1Q572ApnXJ9c';
// // https://www.youtube.com/channel/UCG8rbF3g2AMX70yOd8vqIZg
// $json  =file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id='.$id.'&key='.$api_key) ;
// $image_url=file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=snippet&fields=items%2Fsnippet%2Fthumbnails%2Fdefault&id='.$id.'&key='.$api_key);
// // echo $image;
// // echo($json);

// // Define recursive function to extract nested values
// function printValues($arr) {
//     global $count;
//     global $values;
//     // Check input is an array
//     if(!is_array($arr)){
//         die("<br>"."Sorry: Somethhing Went Wrong");
//     }
//     foreach($arr as $key=>$value){
//         if(is_array($value)){
//             printValues($value);
//         } else{
//             $values[] = $value;
//             $count++;
//         }
//     }
    
//     return array($values);
// }

// $arr = json_decode($json, true);
// $result = printValues($arr);
// echo "<br>";
// // print_r($result);
// $image=json_decode($image_url,true);
// $result2 = printValues($image);
// $url=$result2[0][12];
// // echo "<img src='$url'>";

// $channelid = $result[0][6];
// $views = $result[0][7];
// $comments = $result[0][8];
// $subscribers = $result[0][9];
// $hiddenSubscriber = $result[0][10];
// $videos = $result[0][11];
// $image=$url;

// if (empty($hiddenSubscriber)) {
//   $hiddenSubscriber='No';
// }
// else{
//   $hiddenSubscriber='Yess';
// }



?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Social-Blade | Statistics</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Barlow+Condensed:500,600,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="table.css">

  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
                <a class="navbar-brand" href="index.php"><img src="images/4.gif" height="55"></span>Socialblade</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="index.html" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="services.html" class="nav-link">Services</a></li>
            <li class="nav-item"><a href="gallery.html" class="nav-link">Gallery</a></li>
            <li class="nav-item"><a href="about.html" class="nav-link">About</a></li>
            <li class="nav-item active"><a href="blog.html" class="nav-link">Blog</a></li>
            <li class="nav-item"><a href="contact.html" class="nav-link">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->



    <section class="hero-wrap hero-wrap-2" style="background-color:black" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h2 class="mb-0 bread"><?php echo $name;  ?></h2>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-round-forward"></i></a></span> <span><?php echo $name;  ?> <i class="ion-ios-arrow-round-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-degree-bg">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 sidebar ftco-animate">
            <!-- <br><br> -->
            <div class="sidebar-box bg-light" style="width: 800px; position: center; text-align: center;margin-left: 120px;">
              <img src="<?php echo $image; ?>" style="width: 100px;height: 100px; border-radius: 50%">
              <h2><?php echo $name;  ?></h2>              
            </div>

            <div class="sidebar-box bg-light ftco-animate" style="width: 800px; position: center; margin-left: 120px">
              <h3 class="heading-2" style="text-align: center">Channel Overview</h3>

              <ul class="categories">
                <li><a href="#">Subscribers Hidden <span>(<?php echo($hiddenSubscriber)  ?>)</span></a></li>
                <li><a href="#">Subscribers <span>(<?php echo($subscribers)  ?>)</span></a></li>
                <li><a href="#">Views <span>(<?php echo($views) ?>)</span></a></li>
                <li><a href="#">Videos <span>(<?php echo($videos) ?>)</span></a></li>
                <li><a href="#">Time <span>(<?php echo($time) ?>)</span></a></li>
                <li><a href="#">Channel Id <span>(<?php echo($id)  ?>)</span></a></li>
              </ul>
              <br>
                <p class="button text-center"><a href="#" class="btn btn-primary px-4 py-3">Contact</a></p>
            </div>


            <div class="sidebar-box bg-light ftco-animate" style="width: 800px; position: center; margin-left: 120px">
              <h3 class="heading-2" style="text-align: center">Channel Overview</h3>
              <ul class="categories">
                <table class="tablee" style="width: 750px">
                    <tr>
                        <th>MONTH</th>
                        <th>SUBSCRIBERS</th>
                        <th>VIDEOS</th>
                        <th>VIEWS</th>
                        <th>ESTIMATED EARNINGS</th>
                    </tr>
                    <tr>
                        <td>January</td>
                        <td><?php echo $data_jan[0];  ?></td>
                        <td><?php echo $data_jan[1];  ?></td>
                        <td><?php echo $data_jan[2];  ?></td>
                        <td><?php echo $data_jan[3];  ?></td>
                    </tr>
                    <tr>
                        <td>Febuary</td>
                        <td><?php echo $data_feb[0];  ?></td>
                        <td><?php echo $data_feb[1];  ?></td>
                        <td><?php echo $data_feb[2];  ?></td>
                        <td><?php echo $data_feb[3];  ?></td>
                    </tr>
                    <tr>
                        <td>March</td>
                        <td><?php echo $data_march[0];  ?></td>
                        <td><?php echo $data_march[1];  ?></td>
                        <td><?php echo $data_march[2];  ?></td>
                        <td><?php echo $data_march[3];  ?></td>
                    </tr>
                    <tr>
                        <td>April</td>
                        <td><?php echo $data_april[0];  ?></td>
                        <td><?php echo $data_april[1];  ?></td>
                        <td><?php echo $data_april[2];  ?></td>
                        <td><?php echo $data_april[3];  ?></td>
                    </tr>
                    <tr>
                        <td>May</td>
                        <td><?php echo $data_may[0];  ?></td>
                        <td><?php echo $data_may[1];  ?></td>
                        <td><?php echo $data_may[2];  ?></td>
                        <td><?php echo $data_may[3];  ?></td>
                    </tr>
                    <tr>
                        <td>June</td>
                        <td><?php echo $data_june[0];  ?></td>
                        <td><?php echo $data_june[1];  ?></td>
                        <td><?php echo $data_june[2];  ?></td>
                        <td><?php echo $data_june[3];  ?></td>

                    </tr>
                    <tr>
                      <td>July</td>
                      <td><?php echo $data_july[0];  ?></td>
                      <td><?php echo $data_july[1];  ?></td>
                      <td><?php echo $data_july[2];  ?></td>
                      <td><?php echo $data_july[3];  ?></td>
                   </tr>
                   <tr>
                      <td>August</td>
                      <td><?php echo $data_aug[0];  ?></td>
                      <td><?php echo $data_aug[1];  ?></td>
                      <td><?php echo $data_aug[2];  ?></td>
                      <td><?php echo $data_aug[3];  ?></td>
                   </tr>
                   <tr>
                      <td>September</td>
                      <td><?php echo $data_sep[0];  ?></td>
                      <td><?php echo $data_sep[1];  ?></td>
                      <td><?php echo $data_sep[2];  ?></td>
                      <td><?php echo $data_sep[3];  ?></td>
                   </tr>
                   <tr>
                      <td>October</td>   
                      <td><?php echo $data_oct[0];  ?></td>
                      <td><?php echo $data_oct[1];  ?></td>
                      <td><?php echo $data_oct[2];  ?></td>
                      <td><?php echo $data_oct[3];  ?></td>
                   </tr>
                   <tr>
                    <td>November</td>   
                    <td><?php echo $data_nov[0];  ?></td>
                    <td><?php echo $data_nov[1];  ?></td>
                    <td><?php echo $data_nov[2];  ?></td>
                    <td><?php echo $data_nov[3];  ?></td>
                   </tr>
                   <tr>
                    <td>December</td>   
                    <td><?php echo $data_dec[0];  ?></td>
                    <td><?php echo $data_dec[1];  ?></td>
                    <td><?php echo $data_dec[2];  ?></td>
                    <td><?php echo $data_dec[3];  ?></td>
                   </tr>
                </table>

                
              </ul>
            
            </div>

            <div class="sidebar-box bg-light ftco-animate" style="width: 800px; position: center; margin-left: 120px">
              <h3 class="heading-2" style="text-align: center">Channel Overview</h3>

              <ul class="categories">
              <script src="chart.js"></script>
                  <canvas id="canvas" width="750px" height="500px">
                  <script type="text/javascript">
                      var jan= "<?php echo $sub_jan  ?>";
                      var data = {
                          "xName": "Month",
                          "yName": "Users",
                          "cols": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                          "data": [{ "name": "2016", "values": ["<?php echo $sub_jan ?>", "<?php echo $sub_feb ?>", "<?php echo $sub_march ?>", "<?php echo $sub_april ?>", "<?php echo $sub_may ?>", "<?php echo $sub_june ?>", "<?php echo $sub_july ?>", "<?php echo $sub_aug ?>", "<?php echo $sub_sep ?>", "<?php echo $sub_oct ?>", "<?php echo $sub_nov ?>", "<?php echo $sub_dec ?>"] }]
                          // ,        { "name": "2015", "values": [10, 11, 60, 344, 423, 365, 382, 476, 211, 145, 999, 45] }]
                      };

                      var settings = {
                          "backgroundColor": "gray", 
                          "chartColor": "black",
                          "chartLinesColor": "black",
                          "textColor": ""
                      };

                      var canvas = document.getElementById("canvas");
                      chartify(canvas, data,settings);
                  </script>
                  </canvas>

                
              </ul>
            
            </div>


          </div>
        </div>
      </div>
    </section> 

    <!-- .section -->


    <footer class="ftco-footer ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2 logo">Haircare</h2>
              <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Information</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">FAQs</a></li>
                <li><a href="#" class="py-2 d-block">Privacy</a></li>
                <li><a href="#" class="py-2 d-block">Terms Condition</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Links</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Home</a></li>
                <li><a href="#" class="py-2 d-block">About</a></li>
                <li><a href="#" class="py-2 d-block">Services</a></li>
                <li><a href="#" class="py-2 d-block">Work</a></li>
                <li><a href="#" class="py-2 d-block">Blog</a></li>
                <li><a href="#" class="py-2 d-block">Contact</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Have a Questions?</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text">203 Fake St. Mountain View, San Francisco, California, USA</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text">+2 392 3929 210</span></a></li>
                  <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@yourdomain.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart color-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>