<?php
$id = $_GET['search'];
// echo($channel_code."<br>");
$id = stristr($id, "channel/");
// echo($channel_code."<br>");
$id = str_replace("channel/", "", $id);
// echo($id."<br>");
// $api_key = 'AIzaSyBAedC5mGYO0m8vc0sROju1Q572ApnXJ9c';
// // https://www.youtube.com/channel/UCG8rbF3g2AMX70yOd8vqIZg
// $json  =file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id='.$id.'&key='.$api_key) ;
// $image_url=file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=snippet&fields=items%2Fsnippet%2Fthumbnails%2Fdefault&id='.$id.'&key='.$api_key);
// // echo $image;
// // echo($json);

// // Define recursive function to extract nested values
// function printValues($arr) {
//     global $count;
//     global $values;
//     // Check input is an array
//     if(!is_array($arr)){
//         die("<br>"."Sorry: Somethhing Went Wrong");
//     }
//     foreach($arr as $key=>$value){
//         if(is_array($value)){
//             printValues($value);
//         } else{
//             $values[] = $value;
//             $count++;
//         }
//     }
    
//     return array($values);
// }

// $arr = json_decode($json, true);
// $result = printValues($arr);
// echo "<br>";
// // print_r($result);


// $image=json_decode($image_url,true);
// $result2 = printValues($image);
// $url=$result2[0][12];
// echo "<img src='$url'>";

?>