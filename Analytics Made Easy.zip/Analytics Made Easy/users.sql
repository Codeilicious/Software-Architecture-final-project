-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2020 at 11:02 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `analytics`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `channelid` varchar(50) NOT NULL,
  `views` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `subscribers` int(11) NOT NULL,
  `hiddenSubscriber` varchar(10) NOT NULL,
  `videos` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `channelid`, `views`, `comments`, `subscribers`, `hiddenSubscriber`, `videos`, `time`) VALUES
(9, 'ukhano', 5, 6, 389, 'true', 8, '2020-01-01 10:44:52'),
(10, 'ukhano', 604467, 0, 98, '1', 28, '2020-02-13 10:45:33'),
(11, 'ukhano', 604467, 0, 1208, '1', 288, '2020-03-11 10:46:56'),
(12, 'ukhano', 2147483647, 0, 4908998, '', 4072, '2020-04-02 10:58:53'),
(13, 'ukhano', 344, 0, 678, '1', 2, '2020-05-12 12:14:03'),
(14, 'ukhano', 344, 0, 78, '1', 2, '2020-06-17 12:14:44'),
(15, 'ukhano', 344, 0, 178, '1', 2, '2020-07-22 12:15:03'),
(16, 'ukhano', 344, 0, 768, '1', 2, '2020-08-06 12:15:22'),
(17, 'ukhano', 344, 0, 380, '1', 2, '2020-09-02 12:15:36'),
(19, 'ukhano', 244, 0, 79, '1', 2, '2020-11-11 03:43:36'),
(20, 'ukhano', 34, 0, 208, '1', 2, '2020-12-30 03:43:49'),
(21, 'ukhano', 44, 0, 123, '1', 2, '2020-04-13 03:43:58'),
(22, 'ukhano', 367, 0, 376, '1', 2, '2020-10-13 03:47:40'),
(23, 'Logan Paul', 34444, 0, 3343535, '0', 443, '2020-06-06 09:28:58'),
(24, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:32:11'),
(25, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:32:47'),
(26, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:33:47'),
(27, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:34:44'),
(28, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:35:10'),
(29, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:35:28'),
(30, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:35:55'),
(31, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:35:57'),
(32, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:36:03'),
(33, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:36:42'),
(34, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:36:44'),
(35, 'ukhano', 5, 6, 7, 'true', 8, '2020-06-06 09:49:21'),
(36, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:50:18'),
(37, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:51:00'),
(38, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:54:08'),
(39, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:54:23'),
(40, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:54:28'),
(41, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:54:38'),
(42, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:54:45'),
(43, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:55:14'),
(44, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 09:58:54'),
(45, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 10:00:25'),
(46, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 10:04:36'),
(47, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 10:05:19'),
(48, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 10:05:21'),
(49, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 10:05:24'),
(50, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 10:05:30'),
(51, 'logan bhayya', 5, 6, 7, 'true', 8, '2020-06-06 10:05:36'),
(53, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 10:08:06'),
(54, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 10:09:18'),
(55, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 10:09:21'),
(56, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 10:12:47'),
(57, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 10:12:49'),
(58, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 10:14:40'),
(59, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 10:14:42'),
(60, 'UC-lHJZR3Gqxm24_Vd_AJ5Yw', 2147483647, 0, 105000000, 'No', 4158, '2020-06-06 11:04:32'),
(61, 'UC-lHJZR3Gqxm24_Vd_AJ5Yw', 2147483647, 0, 105000000, 'No', 4158, '2020-06-06 11:04:34'),
(62, 'UC-lHJZR3Gqxm24_Vd_AJ5Yw', 2147483647, 0, 105000000, 'No', 4158, '2020-06-06 11:06:46'),
(63, 'UC-lHJZR3Gqxm24_Vd_AJ5Yw', 2147483647, 0, 105000000, 'No', 4158, '2020-06-06 11:06:48'),
(64, 'UC-lHJZR3Gqxm24_Vd_AJ5Yw', 2147483647, 0, 105000000, 'No', 4158, '2020-06-06 11:10:13'),
(65, 'UC-lHJZR3Gqxm24_Vd_AJ5Yw', 2147483647, 0, 105000000, 'No', 4158, '2019-12-06 11:10:15'),
(66, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 19900000, 'No', 715, '2019-11-06 11:19:00'),
(67, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 19900000, 'No', 715, '2019-10-06 11:19:02'),
(68, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 19770000, 'No', 715, '2019-09-06 11:25:02'),
(69, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 19703000, 'No', 715, '2019-08-06 11:25:32'),
(70, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 19445000, 'No', 715, '2019-07-06 11:25:35'),
(71, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 19272039, 'No', 715, '2019-06-06 11:37:15'),
(72, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 19050907, 'No', 715, '2019-05-06 11:37:42'),
(73, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 18998900, 'No', 715, '2019-04-06 11:37:45'),
(74, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 18000111, 'No', 715, '2019-03-06 11:40:46'),
(75, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 17231987, 'No', 715, '2019-02-06 12:05:24'),
(76, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 17889944, 'No', 715, '2019-01-06 12:05:26'),
(77, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2019-12-06 12:39:14'),
(78, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 12:39:43'),
(79, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 12:39:46'),
(80, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 12:51:34'),
(81, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 12:51:36'),
(82, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 12:54:53'),
(83, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 13:12:21'),
(84, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 13:12:23'),
(85, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 13:14:56'),
(86, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 13:15:39'),
(87, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 13:15:42'),
(88, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 13:16:11'),
(89, 'UCG8rbF3g2AMX70yOd8vqIZg', 2147483647, 0, 21700000, 'No', 715, '2020-06-06 13:16:14'),
(90, 'UCfM3zsQsOnfWNUppiycmBuw', 949538852, 0, 42900000, 'No', 134, '2020-06-06 13:26:04'),
(91, 'UCfM3zsQsOnfWNUppiycmBuw', 949538852, 0, 42900000, 'No', 134, '2020-06-06 13:26:05'),
(92, 'UCfM3zsQsOnfWNUppiycmBuw', 949538852, 0, 42900000, 'No', 134, '2020-06-06 13:26:34'),
(93, 'UCJFp8uSYCjXOMnkUyb3CQ3Q', 2147483647, 0, 18800000, 'No', 3932, '2020-06-06 13:26:47'),
(94, 'UCJFp8uSYCjXOMnkUyb3CQ3Q', 2147483647, 0, 18800000, 'No', 3932, '2020-06-06 13:26:50'),
(95, 'UCGhzrwMFC-1y8HTn8YEZMVg', 23540556, 0, 346000, 'No', 14, '2020-06-06 13:29:40'),
(96, 'UCGhzrwMFC-1y8HTn8YEZMVg', 23540556, 0, 346000, 'No', 14, '2020-06-06 13:29:42'),
(97, 'UCyqR7WkL8i1b6xtSssDmW9w', 403481394, 0, 2640000, 'No', 227, '2020-06-06 13:32:06'),
(98, 'UCyqR7WkL8i1b6xtSssDmW9w', 403481394, 0, 2640000, 'No', 227, '2020-06-06 13:32:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
