<?php
require_once 'config.php';
$data_jan=
$data_feb=
$data_march=
$data_april=
$data_may=
$data_june=
$data_july=
$data_aug=
$data_sep=
$data_oct=
$data_nov=
$data_dec=array('');
$id=$_GET['id'];
// $id=$_GET['id'];


$sql = "SELECT * FROM users where channelid='$id' and time between '2020-01-01' and '2020-01-31' ";
$result = mysqli_query($link,$sql);
if (mysqli_num_rows($result)>0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data_jan[0] =  $row['subscribers'];
        $data_jan[1] =  $row['videos'];
        $data_jan[2] =  $row['views'];
        $data_jan[3] =  ($data_jan[2]/100);
        $data_jan[3] = '$'.($data_jan[3]).'  -  $'.($data_jan[3]*4);
    }
}
else{
    $data_jan[0] =  '';
    $data_jan[1] =  '';
    $data_jan[2] =  '';
    $data_jan[3] =  '';
}





$sql2 = "SELECT * FROM users where channelid='$id' and time between '2020-02-01' and '2020-02-29' ";
$result2 = mysqli_query($link,$sql2);
if (mysqli_num_rows($result2)>0) {
    while ($row2 = mysqli_fetch_assoc($result2)) {
        $data_feb[0] =  $row2['subscribers'];
        $data_feb[1] =  $row2['videos'];
        $data_feb[2] =  $row2['views'];
        $data_feb[3] =  ($data_feb[2]/100);
        $data_feb[3] = '$'.($data_feb[3]).'  -  $'.($data_feb[3]*4);

    }
}
$sql3 = "SELECT * FROM users where channelid='$id' and time between '2020-03-01' and '2020-03-31' ";
$result3 = mysqli_query($link,$sql3);
if (mysqli_num_rows($result3)>0) {
    while ($row3 = mysqli_fetch_assoc($result3)) {
        $data_march[0] =  $row3['subscribers'];
        $data_march[1] =  $row3['videos'];
        $data_march[2] =  $row3['views'];
        $data_march[3] =  ($data_march[2]/100);
        $data_march[3] = '$'.($data_march[3]).'  -  $'.($data_march[3]*4);

    }
}
$sql4 = "SELECT * FROM users where channelid='$id' and time between '2020-04-01' and '2020-04-30' ";
$result4 = mysqli_query($link,$sql4);
if (mysqli_num_rows($result4)>0) {
    while ($row4 = mysqli_fetch_assoc($result4)) {
        $data_april[0] =  $row4['subscribers'];
        $data_april[1] =  $row4['videos'];
        $data_april[2] =  $row4['views'];
        $data_april[3] =  ($data_april[2]/100);
        $data_april[3] = '$'.($data_april[3]).'  -  $'.($data_april[3]*4);

    }
}                
$sql5 = "SELECT * FROM users where channelid='$id' and time between '2020-05-01' and '2020-05-31' ";
$result5 = mysqli_query($link,$sql5);
if (mysqli_num_rows($result5)>0) {
    while ($row5 = mysqli_fetch_assoc($result5)) {
        $data_may[0] =  $row5['subscribers'];
        $data_may[1] =  $row5['videos'];
        $data_may[2] =  $row5['views'];
        $data_may[3] =  ($data_may[2]/100);
        $data_may[3] = '$'.($data_may[3]).'  -  $'.($data_may[3]*4);

    }
}
$sql6 = "SELECT * FROM users where channelid='$id' and time between '2020-06-01' and '2020-06-30' ";
$result6 = mysqli_query($link,$sql6);
if (mysqli_num_rows($result6)>0) {
    while ($row6 = mysqli_fetch_assoc($result6)) {
        // $data_jun[0] =  $row6['subscribers'];
        $data_june[0] =  $row6['subscribers'];
        $data_june[1] =  $row6['videos'];
        $data_june[2] =  $row6['views'];
        $data_june[3] =  ($data_june[2]/100);
        $data_june[3] = '$'.($data_june[3]).'  -  $'.($data_june[3]*4);

    }
}
$sql7 = "SELECT * FROM users where channelid='$id' and time between '2020-07-01' and '2020-07-31' ";
$result7 = mysqli_query($link,$sql7);
if (mysqli_num_rows($result7)>0) {
    while ($row7 = mysqli_fetch_assoc($result7)) {
        $data_july[0] =  $row7['subscribers'];
        $data_july[1] =  $row7['videos'];
        $data_july[2] =  $row7['views'];
        $data_july[3] =  ($data_july[2]/100);
        $data_july[3] = '$'.($data_july[3]).'  -  $'.($data_july[3]*4);
    }
}
$sql8 = "SELECT * FROM users where channelid='$id' and time between '2020-08-01' and '2020-08-31' ";
$result8 = mysqli_query($link,$sql8);
if (mysqli_num_rows($result8)>0) {
    while ($row8 = mysqli_fetch_assoc($result8)) {
        $data_aug[0] =  $row8['subscribers'];
        $data_aug[1] =  $row8['videos'];
        $data_aug[2] =  $row8['views'];
        $data_aug[3] =  ($data_aug[2]/100);
        $data_aug[3] = '$'.($data_aug[3]).'  -  $'.($data_aug[3]*4);

    }
}
$sql9 = "SELECT * FROM users where channelid='$id' and time between '2020-09-01' and '2020-09-30' ";
$result9 = mysqli_query($link,$sql9);
if (mysqli_num_rows($result9)>0) {
    while ($row9 = mysqli_fetch_assoc($result9)) {
        $data_sep[0] =  $row9['subscribers'];
        $data_sep[1] =  $row9['videos'];
        $data_sep[2] =  $row9['views'];
        $data_sep[3] =  ($data_sep[2]/100);
        $data_sep[3] = '$'.($data_sep[3]).'  -  $'.($data_sep[3]*4);

    }
}
$sql10 = "SELECT * FROM users where channelid='$id' and time between '2020-10-01' and '2020-10-31' ";
$result10 = mysqli_query($link,$sql10);
if (mysqli_num_rows($result10)>0) {
    while ($row10 = mysqli_fetch_assoc($result10)) {
        $data_oct[0] =  $row10['subscribers'];
        $data_oct[1] =  $row10['videos'];
        $data_oct[2] =  $row10['views'];
        $data_oct[3] =  ($data_oct[2]/100);
        $data_oct[3] = '$'.($data_oct[3]).'  -  $'.($data_oct[3]*4);

    }
}
else{
    $data_oct[0] ='';
    $data_oct[1] = '';
    $data_oct[2] =  '';
    $data_oct[3] =  '';
}
$sql11 = "SELECT * FROM users where channelid='$id' and time between '2020-11-01' and '2020-11-30' ";
$result11 = mysqli_query($link,$sql11);
if (mysqli_num_rows($result11)>0) {
    while ($row11 = mysqli_fetch_assoc($result11)) {
        $data_nov[0] =  $row11['subscribers'];
        $data_nov[1] =  $row11['time'];
        $data_nov[2] =  $row11['views'];
        $data_nov[3] =  ($data_nov[2]/100);
        $data_nov[3] = '$'.($data_nov[3]).'  -  $'.($data_nov[3]*4);

    }
}
$sql12 = "SELECT * FROM users where channelid='$id' and time between '2020-12-01' and '2020-12-31' ";
$result12 = mysqli_query($link,$sql12);
if (mysqli_num_rows($result12)>0) {
    while ($row12 = mysqli_fetch_assoc($result12)) {
        $data_dec[0] =  $row12['subscribers'];
        $data_dec[1] =  $row12['videos'];
        $data_dec[2] =  $row12['views'];
        $data_dec[3] =  ($data_dec[2]/100);
        $data_dec[3] = '$'.($data_dec[3]).'  -  $'.($data_dec[3]*4);

    }
}
// mysqli_close($link);
?>
