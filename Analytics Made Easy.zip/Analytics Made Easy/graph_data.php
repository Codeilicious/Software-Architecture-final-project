<?php
$sub_jan=
$sub_feb=
$sub_march=
$sub_april=
$sub_may=
$sub_june=
$sub_july=
$sub_aug=
$sub_sep=
$sub_oct=
$sub_nov=
$sub_dec='';
$id='UCG8rbF3g2AMX70yOd8vqIZg';
// $sql6 = "SELECT * FROM users where channelid='$id' and time between '2019-06-01' and '2019-06-30' ";
// $result6 = mysqli_query($link,$sql6);
// if (mysqli_num_rows($result6)>0) {
//     while ($row6 = mysqli_fetch_assoc($result6)) {
//         $sub_jan=
//         $sub_feb=
//         $sub_march=
//         $sub_april=
//         $sub_may=
//         $sub_june=
//         $sub_july=
//         $sub_aug=
//         $sub_sep=
//         $sub_oct=
//         $sub_nov=   

//         $sub_jun =  $row6['subscribers'];

//     }
// }
// $id=$_GET['id'];
// echo $_GET['hidden'];
// echo "<br>";
// echo $_GET['id'];
// echo "<br>";
// echo $_GET['subscribers'];
// echo "<br>";
// echo $_GET['videos'];
// echo "<br>";
// echo $_GET['views'];
// echo "<br>";
// echo $_GET['time'];
// echo "<br>";
require_once 'config.php';
$sql = "SELECT * FROM users where channelid='$id' and time between '2019-01-01' and '2019-01-31' ";
$result = mysqli_query($link,$sql);
if (mysqli_num_rows($result)>0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $sub_jan =  ($row['subscribers']);
    }
}
$sql2 = "SELECT * FROM users where channelid='$id' and time between '2019-02-01' and '2019-02-29' ";
$result2 = mysqli_query($link,$sql2);
if (mysqli_num_rows($result2)>0) {
    while ($row2 = mysqli_fetch_assoc($result2)) {
        $sub_feb =  $row2['subscribers'];
    }
}
$sql3 = "SELECT * FROM users where channelid='$id' and time between '2019-03-01' and '2019-03-31' ";
$result3 = mysqli_query($link,$sql3);
if (mysqli_num_rows($result3)>0) {
    while ($row3 = mysqli_fetch_assoc($result3)) {
        $sub_march =  $row3['subscribers'];
    }
}
$sql4 = "SELECT * FROM users where channelid='$id' and time between '2019-04-01' and '2019-04-30' ";
$result4 = mysqli_query($link,$sql4);
if (mysqli_num_rows($result4)>0) {
    while ($row4 = mysqli_fetch_assoc($result4)) {
        $sub_april =  $row4['subscribers'];
    }
}
$sql5 = "SELECT * FROM users where channelid='$id' and time between '2019-05-01' and '2019-05-31' ";
$result5 = mysqli_query($link,$sql5);
if (mysqli_num_rows($result5)>0) {
    while ($row5 = mysqli_fetch_assoc($result5)) {
        $sub_may =  $row5['subscribers'];
    }
}
$sql6 = "SELECT * FROM users where channelid='$id' and time between '2019-06-01' and '2019-06-30' ";
$result6 = mysqli_query($link,$sql6);
if (mysqli_num_rows($result6)>0) {
    while ($row6 = mysqli_fetch_assoc($result6)) {
        $sub_june =  $row6['subscribers'];
    }
}
$sql7 = "SELECT * FROM users where channelid='$id' and time between '2019-07-01' and '2019-07-31' ";
$result7 = mysqli_query($link,$sql7);
if (mysqli_num_rows($result7)>0) {
    while ($row7 = mysqli_fetch_assoc($result7)) {
        $sub_july =  $row7['subscribers'];
    }
}
$sql8 = "SELECT * FROM users where channelid='$id' and time between '2019-08-01' and '2019-08-30' ";
$result8 = mysqli_query($link,$sql8);
if (mysqli_num_rows($result8)>0) {
    while ($row8 = mysqli_fetch_assoc($result8)) {
        $sub_aug =  $row8['subscribers'];
    }
}
$sql9 = "SELECT * FROM users where channelid='$id' and time between '2019-09-01' and '2019-09-31' ";
$result9 = mysqli_query($link,$sql9);
if (mysqli_num_rows($result9)>0) {
    while ($row9 = mysqli_fetch_assoc($result9)) {
        $sub_sep =  $row9['subscribers'];
    }
}
$sql10 = "SELECT * FROM users where channelid='$id' and time between '2019-10-01' and '2019-10-30' ";
$result10 = mysqli_query($link,$sql10);
if (mysqli_num_rows($result10)>0) {
    while ($row10 = mysqli_fetch_assoc($result10)) {
        $sub_oct =  $row10['subscribers'];
    }
}
$sql11 = "SELECT * FROM users where channelid='$id' and time between '2019-11-01' and '2019-11-31' ";
$result11 = mysqli_query($link,$sql11);
if (mysqli_num_rows($result11)>0) {
    while ($row11 = mysqli_fetch_assoc($result11)) {
        $sub_nov =  $row11['subscribers'];
    }
}
$sql12 = "SELECT * FROM users where channelid='$id' and time between '2019-12-01' and '2019-12-30' ";
$result12 = mysqli_query($link,$sql12);
if (mysqli_num_rows($result12)>0) {
    while ($row12 = mysqli_fetch_assoc($result12)) {
        $sub_dec =  $row12['subscribers'];
    }
}
// mysqli_close($link);
?>
